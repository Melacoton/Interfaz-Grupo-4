/**
 * 
 */
/**
 * @author Usuario
 *
 */
module lab {
	requires java.desktop;
}