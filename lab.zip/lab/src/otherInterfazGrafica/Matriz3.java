package otherInterfazGrafica;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Matriz3 {

	private JFrame frame;
	private JTextField textA1_2;
	private JTextField textA1_3;
	private JTextField textA2_2;
	private JTextField textA2_3;
	private JTextField textB2_1;
	private JTextField textB3_1;
	private JTextField textB2_2;
	private JTextField textB3_2;
	private JTextField textField_8;
	private JTextField textA3_2;
	private JTextField textA3_3;
	private JTextField textA1_1;
	private JTextField textA2_1;
	private JTextField textA3_1;
	private JTextField textB1_1;
	private JTextField textB1_2;
	private JTextField textB1_3;
	private JTextField textB2_3;
	private JTextField textB3_3;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Matriz3 window = new Matriz3();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Matriz3() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	
	private void initialize() {
	    frame = new JFrame(); 
	    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
	    frame.getContentPane().setBackground(new Color(255, 206, 206));
	    frame.setSize(435, 604);

	    frame.setForeground(new Color(0, 0, 0));
	    frame.setBackground(new Color(255, 206, 206));
	    frame.getContentPane().setLayout(null); 
	    frame.getContentPane().setLayout(null);

	      
	     JLabel lblTitulo = new JLabel("Operaciones con matrices");
	     lblTitulo.setBounds(10, 37, 399, 22);
	     lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
	     lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 18));
	     frame.getContentPane().add(lblTitulo);
		
		JLabel lblSubtitulo = new JLabel("Elegir tipo de matriz cuadrada:");
		lblSubtitulo.setBounds(10, 61, 399, 22);
		lblSubtitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblSubtitulo.setFont(new Font("Tahoma", Font.PLAIN, 16));
		frame.getContentPane().add(lblSubtitulo);
		
		JButton btnNewButton2 = new JButton("2x2");
		btnNewButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Matriz2 Opcion1 = new Matriz2();
				Opcion1.setVisible(true);
			}
		});
		btnNewButton2.setBounds(62, 107, 88, 37);
		btnNewButton2.setForeground(new Color(255, 255, 255));
		btnNewButton2.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton2.setBackground(new Color(255, 136, 136));
		frame.getContentPane().add(btnNewButton2);
		
		JTextField lblSubtitulo3 = new JTextField("Matriz cuadrada 3x3");
		lblSubtitulo3.setBounds(74, 170, 268, 22);
		lblSubtitulo3.setBackground(new Color(255, 255, 255));
		lblSubtitulo3.setEditable(false);
		lblSubtitulo3.setHorizontalAlignment(SwingConstants.CENTER);
		lblSubtitulo3.setFont(new Font("Tahoma", Font.BOLD, 15));
		frame.getContentPane().add(lblSubtitulo3);
		
		textA1_2 = new JTextField();
		textA1_2.setBounds(87, 251, 46, 30);
		textA1_2.setHorizontalAlignment(SwingConstants.CENTER);
		textA1_2.setText("0");
		frame.getContentPane().add(textA1_2);
		textA1_2.setColumns(10);
		
		textA1_3 = new JTextField();
		textA1_3.setBounds(143, 251, 46, 30);
		textA1_3.setText("0");
		textA1_3.setHorizontalAlignment(SwingConstants.CENTER);
		textA1_3.setColumns(10);
		frame.getContentPane().add(textA1_3);
		
		JTextField lblSubtitulo4 = new JTextField("Ingrese valores:");
		lblSubtitulo4.setBounds(74, 203, 267, 22);
		lblSubtitulo4.setBackground(new Color(255, 255, 255));
		lblSubtitulo4.setEditable(false);
		lblSubtitulo4.setHorizontalAlignment(SwingConstants.CENTER);
		lblSubtitulo4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		frame.getContentPane().add(lblSubtitulo4);
		
		textA2_2 = new JTextField();
		textA2_2.setBounds(87, 292, 46, 30);
		textA2_2.setText("0");
		textA2_2.setHorizontalAlignment(SwingConstants.CENTER);
		textA2_2.setColumns(10);
		frame.getContentPane().add(textA2_2);
		
		textA2_3 = new JTextField();
		textA2_3.setBounds(143, 292, 46, 30);
		textA2_3.setText("0");
		textA2_3.setHorizontalAlignment(SwingConstants.CENTER);
		textA2_3.setColumns(10);
		frame.getContentPane().add(textA2_3);
		
		textB2_1 = new JTextField();
		textB2_1.setBounds(231, 292, 46, 30);
		textB2_1.setText("0");
		textB2_1.setHorizontalAlignment(SwingConstants.CENTER);
		textB2_1.setColumns(10);
		frame.getContentPane().add(textB2_1);
		
		textB3_1 = new JTextField();
		textB3_1.setBounds(231, 333, 46, 30);
		textB3_1.setText("0");
		textB3_1.setHorizontalAlignment(SwingConstants.CENTER);
		textB3_1.setColumns(10);
		frame.getContentPane().add(textB3_1);
		
		textB2_2 = new JTextField();
		textB2_2.setBounds(287, 292, 46, 30);
		textB2_2.setText("0");
		textB2_2.setHorizontalAlignment(SwingConstants.CENTER);
		textB2_2.setColumns(10);
		frame.getContentPane().add(textB2_2);
		
		textB3_2 = new JTextField();
		textB3_2.setBounds(287, 333, 46, 30);
		textB3_2.setText("0");
		textB3_2.setHorizontalAlignment(SwingConstants.CENTER);
		textB3_2.setColumns(10);
		frame.getContentPane().add(textB3_2);
		
		JButton btnDiv = new JButton("%");
		btnDiv.setBounds(130, 439, 43, 37);
		btnDiv.setForeground(new Color(255, 255, 255));
		btnDiv.setBackground(new Color(255, 100, 100));
		frame.getContentPane().add(btnDiv);
		
		JButton btnMulti = new JButton("x");
		btnMulti.setBounds(130, 391, 43, 37);
		btnMulti.setForeground(new Color(255, 255, 255));
		btnMulti.setBackground(new Color(255, 100, 100));
		frame.getContentPane().add(btnMulti);
		
		JButton btnResta = new JButton("-");
		btnResta.setBounds(74, 439, 43, 37);
		btnResta.setForeground(new Color(255, 255, 255));
		btnResta.setBackground(new Color(255, 100, 100));
		frame.getContentPane().add(btnResta);
		
		JButton btnInversa = new JButton("Inversa");
		btnInversa.setBounds(218, 398, 121, 22);
		btnInversa.setForeground(new Color(255, 255, 255));
		btnInversa.setBackground(new Color(255, 100, 100));
		frame.getContentPane().add(btnInversa);
		
		JButton btnDeterminante = new JButton("Determinante");
		btnDeterminante.setBounds(218, 446, 121, 22);
		btnDeterminante.setForeground(new Color(255, 255, 255));
		btnDeterminante.setBackground(new Color(255, 100, 100));
		frame.getContentPane().add(btnDeterminante);
		
		textField_8 = new JTextField();
		textField_8.setBounds(74, 487, 268, 46);
		textField_8.setFont(new Font("Tahoma", Font.PLAIN, 17));
		textField_8.setForeground(new Color(255, 255, 255));
		textField_8.setHorizontalAlignment(SwingConstants.CENTER);
		textField_8.setBackground(new Color(255, 89, 89));
		frame.getContentPane().add(textField_8);
		textField_8.setColumns(10);
		
		JButton btnNewButton_4 = new JButton("4x4");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Matriz4 Opcion3 = new Matriz4();
				Opcion3.setVisible(true);
			}
		});
		btnNewButton_4.setBounds(267, 107, 88, 37);
		btnNewButton_4.setForeground(new Color(255, 255, 255));
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_4.setBackground(new Color(255, 136, 136));
		frame.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_3 = new JButton("3x3");
		btnNewButton_3.setBounds(164, 107, 88, 37);
		btnNewButton_3.setForeground(new Color(255, 255, 255));
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_3.setBackground(new Color(255, 136, 136));
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnSuma = new JButton("+");
		btnSuma.setForeground(Color.WHITE);
		btnSuma.setBackground(new Color(255, 100, 100));
		btnSuma.setBounds(74, 392, 43, 37);
		frame.getContentPane().add(btnSuma);
		
		textA3_2 = new JTextField();
		textA3_2.setText("0");
		textA3_2.setHorizontalAlignment(SwingConstants.CENTER);
		textA3_2.setColumns(10);
		textA3_2.setBounds(87, 333, 46, 30);
		frame.getContentPane().add(textA3_2);
		
		textA3_3 = new JTextField();
		textA3_3.setText("0");
		textA3_3.setHorizontalAlignment(SwingConstants.CENTER);
		textA3_3.setColumns(10);
		textA3_3.setBounds(143, 333, 46, 30);
		frame.getContentPane().add(textA3_3);
		
		textA1_1 = new JTextField();
		textA1_1.setText("0");
		textA1_1.setHorizontalAlignment(SwingConstants.CENTER);
		textA1_1.setColumns(10);
		textA1_1.setBounds(31, 251, 46, 30);
		frame.getContentPane().add(textA1_1);
		
		textA2_1 = new JTextField();
		textA2_1.setText("0");
		textA2_1.setHorizontalAlignment(SwingConstants.CENTER);
		textA2_1.setColumns(10);
		textA2_1.setBounds(31, 292, 46, 30);
		frame.getContentPane().add(textA2_1);
		
		textA3_1 = new JTextField();
		textA3_1.setText("0");
		textA3_1.setHorizontalAlignment(SwingConstants.CENTER);
		textA3_1.setColumns(10);
		textA3_1.setBounds(31, 333, 46, 30);
		frame.getContentPane().add(textA3_1);
		
		textB1_1 = new JTextField();
		textB1_1.setText("0");
		textB1_1.setHorizontalAlignment(SwingConstants.CENTER);
		textB1_1.setColumns(10);
		textB1_1.setBounds(231, 251, 46, 30);
		frame.getContentPane().add(textB1_1);
		
		textB1_2 = new JTextField();
		textB1_2.setText("0");
		textB1_2.setHorizontalAlignment(SwingConstants.CENTER);
		textB1_2.setColumns(10);
		textB1_2.setBounds(287, 251, 46, 30);
		frame.getContentPane().add(textB1_2);
		
		textB1_3 = new JTextField();
		textB1_3.setText("0");
		textB1_3.setHorizontalAlignment(SwingConstants.CENTER);
		textB1_3.setColumns(10);
		textB1_3.setBounds(344, 251, 46, 30);
		frame.getContentPane().add(textB1_3);
		
		textB2_3 = new JTextField();
		textB2_3.setText("0");
		textB2_3.setHorizontalAlignment(SwingConstants.CENTER);
		textB2_3.setColumns(10);
		textB2_3.setBounds(343, 292, 46, 30);
		frame.getContentPane().add(textB2_3);
		
		textB3_3 = new JTextField();
		textB3_3.setText("0");
		textB3_3.setHorizontalAlignment(SwingConstants.CENTER);
		textB3_3.setColumns(10);
		textB3_3.setBounds(344, 333, 46, 30);
		frame.getContentPane().add(textB3_3);
	}

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		 frame.setVisible(b); 
		 
	}
	}
