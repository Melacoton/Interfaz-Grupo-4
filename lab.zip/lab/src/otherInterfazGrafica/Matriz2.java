package otherInterfazGrafica;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Matriz2 {

	private JFrame frame;
	private JTextField textA1_1;
	private JTextField textA1_2;
	private JTextField textA2_1;
	private JTextField textA2_2;
	private JTextField textB1_1;
	private JTextField textB2_1;
	private JTextField textB1_2;
	private JTextField textB2_2;
	private JTextField textField_8;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Matriz2 window = new Matriz2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Matriz2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	
	private void initialize() {
	    frame = new JFrame(); 
	    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
	    frame.getContentPane().setBackground(new Color(255, 206, 206));
	    frame.setSize(435, 583);

	    frame.setForeground(new Color(0, 0, 0));
	    frame.setBackground(new Color(255, 206, 206));
	    frame.getContentPane().setLayout(null); 
	    frame.getContentPane().setLayout(null);

	   
	    
	     JLabel lblTitulo = new JLabel("Operaciones con matrices");
	     lblTitulo.setBounds(10, 37, 399, 22);
	     lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
	     lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 18));
	     frame.getContentPane().add(lblTitulo);
		
		JLabel lblSubtitulo = new JLabel("Elegir tipo de matriz cuadrada:");
		lblSubtitulo.setBounds(10, 61, 399, 22);
		lblSubtitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblSubtitulo.setFont(new Font("Tahoma", Font.PLAIN, 16));
		frame.getContentPane().add(lblSubtitulo);
		
		JButton btnNewButton = new JButton("2x2");
		btnNewButton.setBounds(62, 107, 88, 37);
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBackground(new Color(255, 136, 136));
		frame.getContentPane().add(btnNewButton);
		
		JTextField lblSubtitulo2 = new JTextField("Matriz cuadrada 2x2");
		lblSubtitulo2.setBounds(74, 170, 268, 22);
		lblSubtitulo2.setBackground(new Color(255, 255, 255));
		lblSubtitulo2.setEditable(false);
		lblSubtitulo2.setHorizontalAlignment(SwingConstants.CENTER);
		lblSubtitulo2.setFont(new Font("Tahoma", Font.BOLD, 15));
		frame.getContentPane().add(lblSubtitulo2);
		
		textA1_1 = new JTextField();
		textA1_1.setBounds(74, 236, 46, 30);
		textA1_1.setHorizontalAlignment(SwingConstants.CENTER);
		textA1_1.setText("0");
		frame.getContentPane().add(textA1_1);
		textA1_1.setColumns(10);
		
		textA1_2 = new JTextField();
		textA1_2.setBounds(130, 236, 46, 30);
		textA1_2.setText("0");
		textA1_2.setHorizontalAlignment(SwingConstants.CENTER);
		textA1_2.setColumns(10);
		frame.getContentPane().add(textA1_2);
		
		JTextField lblSubtitulo3 = new JTextField("Ingrese valores:");
		lblSubtitulo3.setBounds(74, 203, 268, 22);
		lblSubtitulo3.setBackground(new Color(255, 255, 255));
		lblSubtitulo3.setEditable(false);
		lblSubtitulo3.setHorizontalAlignment(SwingConstants.CENTER);
		lblSubtitulo3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		frame.getContentPane().add(lblSubtitulo3);
		
		textA2_1 = new JTextField();
		textA2_1.setBounds(74, 277, 46, 30);
		textA2_1.setText("0");
		textA2_1.setHorizontalAlignment(SwingConstants.CENTER);
		textA2_1.setColumns(10);
		frame.getContentPane().add(textA2_1);
		
		textA2_2 = new JTextField();
		textA2_2.setBounds(130, 277, 46, 30);
		textA2_2.setText("0");
		textA2_2.setHorizontalAlignment(SwingConstants.CENTER);
		textA2_2.setColumns(10);
		frame.getContentPane().add(textA2_2);
		
		textB1_1 = new JTextField();
		textB1_1.setBounds(235, 236, 46, 30);
		textB1_1.setText("0");
		textB1_1.setHorizontalAlignment(SwingConstants.CENTER);
		textB1_1.setColumns(10);
		frame.getContentPane().add(textB1_1);
		
		textB2_1 = new JTextField();
		textB2_1.setBounds(235, 277, 46, 30);
		textB2_1.setText("0");
		textB2_1.setHorizontalAlignment(SwingConstants.CENTER);
		textB2_1.setColumns(10);
		frame.getContentPane().add(textB2_1);
		
		textB1_2 = new JTextField();
		textB1_2.setBounds(295, 236, 46, 30);
		textB1_2.setText("0");
		textB1_2.setHorizontalAlignment(SwingConstants.CENTER);
		textB1_2.setColumns(10);
		frame.getContentPane().add(textB1_2);
		
		textB2_2 = new JTextField();
		textB2_2.setBounds(295, 277, 46, 30);
		textB2_2.setText("0");
		textB2_2.setHorizontalAlignment(SwingConstants.CENTER);
		textB2_2.setColumns(10);
		frame.getContentPane().add(textB2_2);
		
		JButton btnDiv = new JButton("%");
		btnDiv.setBounds(133, 392, 43, 37);
		btnDiv.setForeground(new Color(255, 255, 255));
		btnDiv.setBackground(new Color(255, 100, 100));
		frame.getContentPane().add(btnDiv);
		
		JButton btnMulti = new JButton("x");
		btnMulti.setBounds(133, 344, 43, 37);
		btnMulti.setForeground(new Color(255, 255, 255));
		btnMulti.setBackground(new Color(255, 100, 100));
		frame.getContentPane().add(btnMulti);
		
		JButton btnResta = new JButton("-");
		btnResta.setBounds(74, 392, 43, 37);
		btnResta.setForeground(new Color(255, 255, 255));
		btnResta.setBackground(new Color(255, 100, 100));
		frame.getContentPane().add(btnResta);
		
		JButton btnInversa = new JButton("Inversa");
		btnInversa.setBounds(218, 351, 121, 22);
		btnInversa.setForeground(new Color(255, 255, 255));
		btnInversa.setBackground(new Color(255, 100, 100));
		frame.getContentPane().add(btnInversa);
		
		JButton btnDeterminante = new JButton("Determinante");
		btnDeterminante.setBounds(218, 399, 121, 22);
		btnDeterminante.setForeground(new Color(255, 255, 255));
		btnDeterminante.setBackground(new Color(255, 100, 100));
		frame.getContentPane().add(btnDeterminante);
		
		textField_8 = new JTextField();
		textField_8.setBounds(74, 453, 268, 46);
		textField_8.setFont(new Font("Tahoma", Font.PLAIN, 17));
		textField_8.setForeground(new Color(255, 255, 255));
		textField_8.setHorizontalAlignment(SwingConstants.CENTER);
		textField_8.setBackground(new Color(255, 89, 89));
		frame.getContentPane().add(textField_8);
		textField_8.setColumns(10);
		
		JButton btnNewButton_4 = new JButton("4x4");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Matriz4 Opcion3 = new Matriz4();
				Opcion3.setVisible(true);
				
			}
		});
		btnNewButton_4.setBounds(267, 107, 88, 37);
		btnNewButton_4.setForeground(new Color(255, 255, 255));
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_4.setBackground(new Color(255, 136, 136));
		frame.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_3 = new JButton("3x3");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Matriz3 Opcion2 = new Matriz3();
				Opcion2.setVisible(true);
				
			}
		});
		btnNewButton_3.setBounds(164, 107, 88, 37);
		btnNewButton_3.setForeground(new Color(255, 255, 255));
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_3.setBackground(new Color(255, 136, 136));
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnSuma = new JButton("+");
		btnSuma.setForeground(Color.WHITE);
		btnSuma.setBackground(new Color(255, 100, 100));
		btnSuma.setBounds(74, 344, 43, 37);
		frame.getContentPane().add(btnSuma);
	}

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		 frame.setVisible(b); 
		 
	}
	}

