package otherInterfazGrafica;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Matriz4 {

	private JFrame frame;
	private JTextField textA2_3;
	private JTextField textA2_4;
	private JTextField textA3_3;
	private JTextField textA3_4;
	private JTextField textB3_1;
	private JTextField textB4_1;
	private JTextField textB3_2;
	private JTextField textB4_2;
	private JTextField textField_8;
	private JTextField textA4_3;
	private JTextField textA4_4;
	private JTextField textA2_2;
	private JTextField textA3_2;
	private JTextField textA4_2;
	private JTextField textB2_1;
	private JTextField textB2_2;
	private JTextField textB2_3;
	private JTextField textB3_3;
	private JTextField textB4_3;
	private JTextField textA2_1;
	private JTextField textA3_1;
	private JTextField textA4_1;
	private JTextField textB2_4;
	private JTextField textB3_4;
	private JTextField textB4_4;
	private JTextField textB1_4;
	private JTextField textB1_3;
	private JTextField textB1_2;
	private JTextField textB1_1;
	private JTextField textA1_4;
	private JTextField textA1_3;
	private JTextField textA1_2;
	private JTextField textA1_1;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Matriz4 window = new Matriz4();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Matriz4() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	
	private void initialize() {
	    frame = new JFrame(); 
	    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); //
	    frame.getContentPane().setBackground(new Color(255, 206, 206));
	    frame.setSize(540, 654);

	    frame.setForeground(new Color(0, 0, 0));
	    frame.setBackground(new Color(255, 206, 206));
	    frame.getContentPane().setLayout(null); 
	    frame.getContentPane().setLayout(null);

	     JLabel lblTitulo = new JLabel("Operaciones con matrices");
	     lblTitulo.setBounds(10, 37, 504, 22);
	     lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
	     lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 18));
	     frame.getContentPane().add(lblTitulo);
		
		JLabel lblSubtitulo = new JLabel("Elegir tipo de matriz cuadrada:");
		lblSubtitulo.setBounds(10, 61, 504, 22);
		lblSubtitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblSubtitulo.setFont(new Font("Tahoma", Font.PLAIN, 16));
		frame.getContentPane().add(lblSubtitulo);
		
		JButton btnNewButton = new JButton("2x2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Matriz2 Opcion1 = new Matriz2();
				Opcion1.setVisible(true);
			}
		});
		btnNewButton.setBounds(115, 101, 88, 37);
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBackground(new Color(255, 136, 136));
		frame.getContentPane().add(btnNewButton);
		
		JTextField lblNewLabel = new JTextField("Matriz cuadrada 4x4");
		lblNewLabel.setBounds(126, 163, 268, 22);
		lblNewLabel.setBackground(new Color(255, 255, 255));
		lblNewLabel.setEditable(false);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		frame.getContentPane().add(lblNewLabel);
		
		textA2_3 = new JTextField();
		textA2_3.setBounds(139, 285, 46, 30);
		textA2_3.setHorizontalAlignment(SwingConstants.CENTER);
		textA2_3.setText("0");
		frame.getContentPane().add(textA2_3);
		textA2_3.setColumns(10);
		
		textA2_4 = new JTextField();
		textA2_4.setBounds(195, 285, 46, 30);
		textA2_4.setText("0");
		textA2_4.setHorizontalAlignment(SwingConstants.CENTER);
		textA2_4.setColumns(10);
		frame.getContentPane().add(textA2_4);
		
		JTextField lblIngreseValores = new JTextField("Ingrese valores:");
		lblIngreseValores.setBounds(126, 196, 267, 22);
		lblIngreseValores.setBackground(new Color(255, 255, 255));
		lblIngreseValores.setEditable(false);
		lblIngreseValores.setHorizontalAlignment(SwingConstants.CENTER);
		lblIngreseValores.setFont(new Font("Tahoma", Font.PLAIN, 15));
		frame.getContentPane().add(lblIngreseValores);
		
		textA3_3 = new JTextField();
		textA3_3.setBounds(139, 326, 46, 30);
		textA3_3.setText("0");
		textA3_3.setHorizontalAlignment(SwingConstants.CENTER);
		textA3_3.setColumns(10);
		frame.getContentPane().add(textA3_3);
		
		textA3_4 = new JTextField();
		textA3_4.setBounds(195, 326, 46, 30);
		textA3_4.setText("0");
		textA3_4.setHorizontalAlignment(SwingConstants.CENTER);
		textA3_4.setColumns(10);
		frame.getContentPane().add(textA3_4);
		
		textB3_1 = new JTextField();
		textB3_1.setBounds(283, 326, 46, 30);
		textB3_1.setText("0");
		textB3_1.setHorizontalAlignment(SwingConstants.CENTER);
		textB3_1.setColumns(10);
		frame.getContentPane().add(textB3_1);
		
		textB4_1 = new JTextField();
		textB4_1.setBounds(283, 367, 46, 30);
		textB4_1.setText("0");
		textB4_1.setHorizontalAlignment(SwingConstants.CENTER);
		textB4_1.setColumns(10);
		frame.getContentPane().add(textB4_1);
		
		textB3_2 = new JTextField();
		textB3_2.setBounds(339, 326, 46, 30);
		textB3_2.setText("0");
		textB3_2.setHorizontalAlignment(SwingConstants.CENTER);
		textB3_2.setColumns(10);
		frame.getContentPane().add(textB3_2);
		
		textB4_2 = new JTextField();
		textB4_2.setBounds(339, 367, 46, 30);
		textB4_2.setText("0");
		textB4_2.setHorizontalAlignment(SwingConstants.CENTER);
		textB4_2.setColumns(10);
		frame.getContentPane().add(textB4_2);
		
		JButton btnDiv = new JButton("%");
		btnDiv.setBounds(178, 491, 43, 37);
		btnDiv.setForeground(new Color(255, 255, 255));
		btnDiv.setBackground(new Color(255, 100, 100));
		frame.getContentPane().add(btnDiv);
		
		JButton btnX = new JButton("x");
		btnX.setBounds(178, 443, 43, 37);
		btnX.setForeground(new Color(255, 255, 255));
		btnX.setBackground(new Color(255, 100, 100));
		frame.getContentPane().add(btnX);
		
		JButton btnDiv_3 = new JButton("-");
		btnDiv_3.setBounds(125, 491, 43, 37);
		btnDiv_3.setForeground(new Color(255, 255, 255));
		btnDiv_3.setBackground(new Color(255, 100, 100));
		frame.getContentPane().add(btnDiv_3);
		
		JButton btnInversa = new JButton("Inversa");
		btnInversa.setBounds(283, 450, 121, 22);
		btnInversa.setForeground(new Color(255, 255, 255));
		btnInversa.setBackground(new Color(255, 100, 100));
		frame.getContentPane().add(btnInversa);
		
		JButton btnDeterminante = new JButton("Determinante");
		btnDeterminante.setBounds(283, 498, 121, 22);
		btnDeterminante.setForeground(new Color(255, 255, 255));
		btnDeterminante.setBackground(new Color(255, 100, 100));
		frame.getContentPane().add(btnDeterminante);
		
		textField_8 = new JTextField();
		textField_8.setBounds(124, 539, 284, 46);
		textField_8.setFont(new Font("Tahoma", Font.PLAIN, 17));
		textField_8.setForeground(new Color(255, 255, 255));
		textField_8.setHorizontalAlignment(SwingConstants.CENTER);
		textField_8.setBackground(new Color(255, 89, 89));
		frame.getContentPane().add(textField_8);
		textField_8.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("4x4");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setBounds(320, 101, 88, 37);
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.setBackground(new Color(255, 136, 136));
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("3x3");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Matriz3 Opcion2 = new Matriz3();
				Opcion2.setVisible(true);
			}
		});
		btnNewButton_2.setBounds(217, 101, 88, 37);
		btnNewButton_2.setForeground(new Color(255, 255, 255));
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_2.setBackground(new Color(255, 136, 136));
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnSuma = new JButton("+");
		btnSuma.setForeground(Color.WHITE);
		btnSuma.setBackground(new Color(255, 100, 100));
		btnSuma.setBounds(125, 443, 43, 37);
		frame.getContentPane().add(btnSuma);
		
		textA4_3 = new JTextField();
		textA4_3.setText("0");
		textA4_3.setHorizontalAlignment(SwingConstants.CENTER);
		textA4_3.setColumns(10);
		textA4_3.setBounds(139, 367, 46, 30);
		frame.getContentPane().add(textA4_3);
		
		textA4_4 = new JTextField();
		textA4_4.setText("0");
		textA4_4.setHorizontalAlignment(SwingConstants.CENTER);
		textA4_4.setColumns(10);
		textA4_4.setBounds(195, 367, 46, 30);
		frame.getContentPane().add(textA4_4);
		
		textA2_2 = new JTextField();
		textA2_2.setText("0");
		textA2_2.setHorizontalAlignment(SwingConstants.CENTER);
		textA2_2.setColumns(10);
		textA2_2.setBounds(83, 285, 46, 30);
		frame.getContentPane().add(textA2_2);
		
		textA3_2 = new JTextField();
		textA3_2.setText("0");
		textA3_2.setHorizontalAlignment(SwingConstants.CENTER);
		textA3_2.setColumns(10);
		textA3_2.setBounds(83, 326, 46, 30);
		frame.getContentPane().add(textA3_2);
		
		textA4_2 = new JTextField();
		textA4_2.setText("0");
		textA4_2.setHorizontalAlignment(SwingConstants.CENTER);
		textA4_2.setColumns(10);
		textA4_2.setBounds(83, 367, 46, 30);
		frame.getContentPane().add(textA4_2);
		
		textB2_1 = new JTextField();
		textB2_1.setText("0");
		textB2_1.setHorizontalAlignment(SwingConstants.CENTER);
		textB2_1.setColumns(10);
		textB2_1.setBounds(283, 285, 46, 30);
		frame.getContentPane().add(textB2_1);
		
		textB2_2 = new JTextField();
		textB2_2.setText("0");
		textB2_2.setHorizontalAlignment(SwingConstants.CENTER);
		textB2_2.setColumns(10);
		textB2_2.setBounds(339, 285, 46, 30);
		frame.getContentPane().add(textB2_2);
		
		textB2_3 = new JTextField();
		textB2_3.setText("0");
		textB2_3.setHorizontalAlignment(SwingConstants.CENTER);
		textB2_3.setColumns(10);
		textB2_3.setBounds(396, 285, 46, 30);
		frame.getContentPane().add(textB2_3);
		
		textB3_3 = new JTextField();
		textB3_3.setText("0");
		textB3_3.setHorizontalAlignment(SwingConstants.CENTER);
		textB3_3.setColumns(10);
		textB3_3.setBounds(395, 326, 46, 30);
		frame.getContentPane().add(textB3_3);
		
		textB4_3 = new JTextField();
		textB4_3.setText("0");
		textB4_3.setHorizontalAlignment(SwingConstants.CENTER);
		textB4_3.setColumns(10);
		textB4_3.setBounds(396, 367, 46, 30);
		frame.getContentPane().add(textB4_3);
		
		textA2_1 = new JTextField();
		textA2_1.setText("0");
		textA2_1.setHorizontalAlignment(SwingConstants.CENTER);
		textA2_1.setColumns(10);
		textA2_1.setBounds(27, 285, 46, 30);
		frame.getContentPane().add(textA2_1);
		
		textA3_1 = new JTextField();
		textA3_1.setText("0");
		textA3_1.setHorizontalAlignment(SwingConstants.CENTER);
		textA3_1.setColumns(10);
		textA3_1.setBounds(26, 326, 46, 30);
		frame.getContentPane().add(textA3_1);
		
		textA4_1 = new JTextField();
		textA4_1.setText("0");
		textA4_1.setHorizontalAlignment(SwingConstants.CENTER);
		textA4_1.setColumns(10);
		textA4_1.setBounds(26, 367, 46, 30);
		frame.getContentPane().add(textA4_1);
		
		textB2_4 = new JTextField();
		textB2_4.setText("0");
		textB2_4.setHorizontalAlignment(SwingConstants.CENTER);
		textB2_4.setColumns(10);
		textB2_4.setBounds(452, 285, 46, 30);
		frame.getContentPane().add(textB2_4);
		
		textB3_4 = new JTextField();
		textB3_4.setText("0");
		textB3_4.setHorizontalAlignment(SwingConstants.CENTER);
		textB3_4.setColumns(10);
		textB3_4.setBounds(452, 326, 46, 30);
		frame.getContentPane().add(textB3_4);
		
		textB4_4 = new JTextField();
		textB4_4.setText("0");
		textB4_4.setHorizontalAlignment(SwingConstants.CENTER);
		textB4_4.setColumns(10);
		textB4_4.setBounds(452, 367, 46, 30);
		frame.getContentPane().add(textB4_4);
		
		textB1_4 = new JTextField();
		textB1_4.setText("0");
		textB1_4.setHorizontalAlignment(SwingConstants.CENTER);
		textB1_4.setColumns(10);
		textB1_4.setBounds(452, 242, 46, 30);
		frame.getContentPane().add(textB1_4);
		
		textB1_3 = new JTextField();
		textB1_3.setText("0");
		textB1_3.setHorizontalAlignment(SwingConstants.CENTER);
		textB1_3.setColumns(10);
		textB1_3.setBounds(396, 242, 46, 30);
		frame.getContentPane().add(textB1_3);
		
		textB1_2 = new JTextField();
		textB1_2.setText("0");
		textB1_2.setHorizontalAlignment(SwingConstants.CENTER);
		textB1_2.setColumns(10);
		textB1_2.setBounds(339, 242, 46, 30);
		frame.getContentPane().add(textB1_2);
		
		textB1_1 = new JTextField();
		textB1_1.setText("0");
		textB1_1.setHorizontalAlignment(SwingConstants.CENTER);
		textB1_1.setColumns(10);
		textB1_1.setBounds(283, 244, 46, 30);
		frame.getContentPane().add(textB1_1);
		
		textA1_4 = new JTextField();
		textA1_4.setText("0");
		textA1_4.setHorizontalAlignment(SwingConstants.CENTER);
		textA1_4.setColumns(10);
		textA1_4.setBounds(195, 244, 46, 30);
		frame.getContentPane().add(textA1_4);
		
		textA1_3 = new JTextField();
		textA1_3.setText("0");
		textA1_3.setHorizontalAlignment(SwingConstants.CENTER);
		textA1_3.setColumns(10);
		textA1_3.setBounds(139, 244, 46, 30);
		frame.getContentPane().add(textA1_3);
		
		textA1_2 = new JTextField();
		textA1_2.setText("0");
		textA1_2.setHorizontalAlignment(SwingConstants.CENTER);
		textA1_2.setColumns(10);
		textA1_2.setBounds(83, 244, 46, 30);
		frame.getContentPane().add(textA1_2);
		
		textA1_1 = new JTextField();
		textA1_1.setText("0");
		textA1_1.setHorizontalAlignment(SwingConstants.CENTER);
		textA1_1.setColumns(10);
		textA1_1.setBounds(26, 242, 46, 30);
		frame.getContentPane().add(textA1_1);
	}

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		 frame.setVisible(b); 
		 
	}
	}
