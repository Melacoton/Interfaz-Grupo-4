package otherInterfazGrafica;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JTable;

public class Matrices {

	private JFrame frame;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Matrices window = new Matrices();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Matrices() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 217, 217));
		frame.setBounds(100, 100, 450, 338);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblTitulo = new JLabel("Operaciones con matrices");
		lblTitulo.setBounds(0, 63, 424, 22);
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 18));
		frame.getContentPane().add(lblTitulo);
		
		JLabel lblSubtitulo = new JLabel("Elegir tipo de matriz cuadrada:");
		lblSubtitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblSubtitulo.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblSubtitulo.setBounds(0, 108, 434, 22);
		frame.getContentPane().add(lblSubtitulo);
		
		JButton btnNewButton = new JButton("2x2");
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(255, 113, 113));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(56, 152, 81, 37);
		frame.getContentPane().add(btnNewButton);
		
		
		
		JButton btnx_1 = new JButton("4x4");
		btnx_1.setForeground(new Color(255, 255, 255));
		btnx_1.setBackground(new Color(255, 113, 113));
		btnx_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnx_1.setBounds(296, 152, 81, 37);
		frame.getContentPane().add(btnx_1);
		
		table = new JTable();
		table.setBounds(187, 188, 1, 1);
		frame.getContentPane().add(table);
	}
}
