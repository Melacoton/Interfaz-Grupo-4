package otherInterfazGrafica;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.CardLayout;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JComboBox;


@SuppressWarnings("serial")

public class pantalla extends JFrame {
    private JPanel contentPane;
    private JTextField numA;
    private JTextField numB;
    private JTextField lblResult;
    private JPanel PanelVectores;
    private JPanel mainPanel;
    private JPanel PanelMatriz;
    private JPanel PanelSisEcu;
	private JTable table;
	private JFrame frame;
/**
* Launch the application.
*/
public static void main(String[] args) {
   EventQueue.invokeLater(new Runnable() {
     public void run() {
       try {
	pantalla frame = new pantalla();
    frame.setVisible(true);
   } catch (Exception e) {
   e.printStackTrace();
   }
   }
  });
}
/**
* Create the frame.
*/
public pantalla() {
	setTitle("Calculadora");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setBounds(100, 100, 475, 509);
    mainPanel = new JPanel(new CardLayout());
    setContentPane(mainPanel);

    JFrame mainFrame = new JFrame("Ventana Principal");
    mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    //INICIALIZACION DE PANELES
    contentPane = new JPanel();
    contentPane.setBackground(new Color(255, 206, 206));
    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
    mainPanel.add(contentPane, "Operaciones");
    contentPane.setLayout(null);
    
    PanelVectores = new JPanel();
    PanelVectores.setBackground(new Color(255, 206, 206));
    mainPanel.add(PanelVectores, "Vectores");
    PanelVectores.setLayout(null);
    initializePanelVectores();
    
    PanelMatriz = new JPanel();
    PanelMatriz.setBackground(new Color(255, 206, 206));
    mainPanel.add(PanelMatriz, "Matrices");
    PanelMatriz.setLayout(null);
    initializePanelMatrices();
    
    PanelSisEcu = new JPanel();
    PanelSisEcu.setBackground(new Color(255, 206, 206));
    mainPanel.add(PanelSisEcu, "Sist.Ecuaciones");
    PanelSisEcu.setLayout(null);
    initializePanelSistEcu();
  
    
   
    //BOTONES OPERACIONES SIMPLES
    JButton btnSuma = new JButton("+");
    btnSuma.setForeground(new Color(0, 0, 0));
    btnSuma.setBackground(new Color(255, 119, 119));
    btnSuma.setBounds(123, 274, 41, 37);
    contentPane.add(btnSuma);
    
    btnSuma.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
          try {
             int num1 = Integer.parseInt(numA.getText());
             int num2 = Integer.parseInt(numB.getText());
             int suma = num1 + num2;
             lblResult.setText("Resultado: " + suma);
              } catch (NumberFormatException ex) {
            lblResult.setText("Ingrese números válidos");
             }
           }
        });
    
    
    JButton btnResta = new JButton("-");
    btnResta.setForeground(new Color(0, 0, 0));
    btnResta.setBackground(new Color(255, 119, 119));
    btnResta.setBounds(174, 274, 41, 37);
    contentPane.add(btnResta);
    
    btnResta.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
       try {
         int num1 = Integer.parseInt(numA.getText());
         int num2 = Integer.parseInt(numB.getText());
         int resta = num1 - num2;
         lblResult.setText("Resultado: " + resta);
           } catch (NumberFormatException ex) {
         lblResult.setText("Ingrese números válidos");
          }
        }
     });
    
    
    JButton btnMult = new JButton("x"); 
    btnMult.setForeground(new Color(0, 0, 0));
    btnMult.setBackground(new Color(255, 119, 119));
    btnMult.setBounds(225, 274, 41, 37);
    contentPane.add(btnMult);
    
    btnMult.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
      try {
        int num1 = Integer.parseInt(numA.getText());
        int num2 = Integer.parseInt(numB.getText());
        int mult = num1 * num2;
        lblResult.setText("Resultado: " + mult);
          } catch (NumberFormatException ex) {
        lblResult.setText("Ingrese números válidos");
         }
       }
    });
    
    
    JButton btnDiv = new JButton("%");
    btnDiv.setForeground(new Color(0, 0, 0));
    btnDiv.setBackground(new Color(255, 119, 119));
    btnDiv.setBounds(276, 274, 43, 37);
    contentPane.add(btnDiv);
    
    btnDiv.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
       try {
         float num1 = Float.parseFloat(numA.getText());
         float num2 = Float.parseFloat(numB.getText());
         if(num2==0) {
	     lblResult.setText("Error: division por 0");
          }
         else {
         float div = (float)num1 / num2;
         lblResult.setText("Resultado: " + div);
         }
         } catch (NumberFormatException ex) {
         lblResult.setText("Ingrese números válidos");
          }
        }
     });
    
    JButton btnPotencia = new JButton("x^n"); //AGREGUE BOTON POTENCIA
    btnPotencia.setForeground(Color.BLACK);
    btnPotencia.setBackground(new Color(255, 119, 119));
    btnPotencia.setBounds(155, 322, 60, 30);
    contentPane.add(btnPotencia);
    

    btnPotencia.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
      try {
	      double num1 = Double.parseDouble(numA.getText());
	      double num2 = Double.parseDouble(numB.getText());
	      double potencia = Math.pow(num1, num2); //USE DOUBLE Y MATH.POW PARA CALCULAR
          lblResult.setText("Resultado: " + potencia);
           } catch (NumberFormatException ex) {
          lblResult.setText("Ingrese números válidos");
         }
       }
    });
    
    
    JButton btnRaiz = new JButton("n√x");
    btnRaiz.setForeground(Color.BLACK);
    btnRaiz.setBackground(new Color(255, 119, 119));
    btnRaiz.setBounds(225, 322, 60, 30);
    contentPane.add(btnRaiz);
    
    btnRaiz.addActionListener(new ActionListener() { 
    	public void actionPerformed(ActionEvent e) {
    	try {
    		float num1 = Float.parseFloat(numA.getText());
    		float num2 = Float.parseFloat(numB.getText());
    		if(num1<0 && num2 != Math.floor(num2)) {
    			lblResult.setText("Error: valores invalidos");
    		}
    		else {
    		float raiz = (float)Math.pow(num1, 1.0 / num2); //CUENTA PARA CALCULAR LA RAIZ
    	lblResult.setText("Resultado: " + raiz); 	}
    	} catch (NumberFormatException ex) {
    	lblResult.setText("Ingrese números válidos");
    	}
      }
    });
    
    
    
    //OPERACIONES SIMPLES INGRESO DE VALORES
    JLabel lblTitulo = new JLabel("Operaciones simples");
    lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
    lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 18));
    lblTitulo.setBounds(10, 50, 439, 22);
    contentPane.add(lblTitulo);

    JTextField txtrValorA = new JTextField();
    txtrValorA.setHorizontalAlignment(SwingConstants.CENTER);
    txtrValorA.setForeground(new Color(22, 22, 22));
    txtrValorA.setFont(new Font("Meiryo", Font.PLAIN, 14));
    txtrValorA.setBackground(new Color(255, 255, 255));
    txtrValorA.setEditable(false);
    txtrValorA.setText("Ingrese el primer valor:");
    txtrValorA.setBounds(132, 94, 187, 22);
    contentPane.add(txtrValorA);

    numA = new JTextField();
    numA.setHorizontalAlignment(SwingConstants.CENTER);
    numA.setText("0");
    numA.setBounds(174, 138, 100, 20);
    numA.setColumns(10);
    contentPane.add(numA);
    
    numB = new JTextField();
    numB.setHorizontalAlignment(SwingConstants.CENTER);
    numB.setText("0");
    numB.setColumns(10);
    numB.setBounds(174, 223, 100, 20);
    contentPane.add(numB); 

    lblResult = new JTextField("");
    lblResult.setFont(new Font("Tahoma", Font.PLAIN, 17));
    lblResult.setEditable(false);
    lblResult.setForeground(new Color(255, 255, 255));
    lblResult.setBackground(new Color(255, 89, 89));
    lblResult.setHorizontalAlignment(SwingConstants.CENTER);
    lblResult.setBounds(105, 372, 239, 30);
    contentPane.add(lblResult);
    
    JTextField txtrValorB = new JTextField();
    txtrValorB.setHorizontalAlignment(SwingConstants.CENTER);
    txtrValorB.setText("Ingrese el segundo valor:");
    txtrValorB.setForeground(new Color(22, 22, 22));
    txtrValorB.setFont(new Font("Meiryo", Font.PLAIN, 14));
    txtrValorB.setEditable(false);
    txtrValorB.setBackground(new Color(255, 255, 255));
    txtrValorB.setBounds(132, 177, 187, 22);
    contentPane.add(txtrValorB);
    
    
    String[] opcion = {"Operaciones", "Vectores", "Matrices", "Sist.Ecuaciones"};
    
    JComboBox<String> ComboBox = new JComboBox<>(opcion);
    ComboBox.setBounds(305, 11, 131, 22);
    contentPane.add(ComboBox);

    JComboBox<String> comboBox2 = new JComboBox<>(opcion);
    comboBox2.setBounds(300, 10, 131, 22);
    PanelVectores.add(comboBox2);

    JComboBox<String> ComboBox3 = new JComboBox<>(opcion);
    ComboBox3.setBounds(300, 10, 131, 22);
    PanelMatriz.add(ComboBox3);

    JComboBox<String> comboBox4 = new JComboBox<>(opcion);
    comboBox4.setBounds(300, 10, 131, 22);
    PanelSisEcu.add(comboBox4); 
    
    
    //AGREGAR UN COMBOBOX PARA CADA PANEL
    ComboBox.addActionListener(new ActionListener() {
    	public void actionPerformed(ActionEvent e) {
    	String selectedOpcion = (String) ComboBox.getSelectedItem();
    	CardLayout cl = (CardLayout) (mainPanel.getLayout());
    	if (selectedOpcion.equals("Operaciones")) {
    	cl.show(mainPanel, "Operaciones");
    	} else if (selectedOpcion.equals("Vectores")) {
    	cl.show(mainPanel, "Vectores");
    	} else if (selectedOpcion.equals("Vectores")) {
    	cl.show(mainPanel, "Vectores");
    	} else if (selectedOpcion.equals("Matrices")) {
    	cl.show(mainPanel, "Matrices");
    	} else if (selectedOpcion.equals("Sist.Ecuaciones")) {
    	cl.show(mainPanel, "Sist.Ecuaciones");
    	}
    	}
    	});
    
    comboBox2.addActionListener(new ActionListener() {
    	public void actionPerformed(ActionEvent e) {
    	String selectedOperation = (String) comboBox2.getSelectedItem();
    	CardLayout cl = (CardLayout) (mainPanel.getLayout());
    	if (selectedOperation.equals("Operaciones")) {
    	cl.show(mainPanel, "Operaciones");
    	} else if (selectedOperation.equals("Vectores")) {
    	cl.show(mainPanel, "Vectores");
    	} else if (selectedOperation.equals("Vectores")) {
    	cl.show(mainPanel, "Vectores");
    	} else if (selectedOperation.equals("Matrices")) {
    	cl.show(mainPanel, "Matrices");
    	} else if (selectedOperation.equals("Sist.Ecuaciones")) {
    	cl.show(mainPanel, "Sist.Ecuaciones");
    	}
    	}
    	});
    
    ComboBox3.addActionListener(new ActionListener() {
    	public void actionPerformed(ActionEvent e) {
    	String selectedOperation = (String) ComboBox3.getSelectedItem();
    	CardLayout cl = (CardLayout) (mainPanel.getLayout());
    	if (selectedOperation.equals("Operaciones")) {
    	cl.show(mainPanel, "Operaciones");
    	} else if (selectedOperation.equals("Matrices")) {
    	cl.show(mainPanel, "Matrices");
    	} else if (selectedOperation.equals("Vectores")) {
    	cl.show(mainPanel, "Vectores");
    	} else if (selectedOperation.equals("Matrices")) {
    	cl.show(mainPanel, "Matrices");
    	} else if (selectedOperation.equals("Sist.Ecuaciones")) {
    	cl.show(mainPanel, "Sist.Ecuaciones");
    	}
    	}
    	});
    
    comboBox4.addActionListener(new ActionListener() {
    	public void actionPerformed(ActionEvent e) {
    	String selectedOperation = (String) comboBox4.getSelectedItem();
    	CardLayout cl = (CardLayout) (mainPanel.getLayout());
    	if (selectedOperation.equals("Operaciones")) {
    	cl.show(mainPanel, "Operaciones");
    	} else if (selectedOperation.equals("Sist.Ecuaciones")) {
    	cl.show(mainPanel, "Sist.Ecuaciones");
    	} else if (selectedOperation.equals("Vectores")) {
    	cl.show(mainPanel, "Vectores");
    	} else if (selectedOperation.equals("Matrices")) {
    	cl.show(mainPanel, "Matrices");
    	} else if (selectedOperation.equals("Sist.Ecuaciones")) {
    	cl.show(mainPanel, "Sist.Ecuaciones");
    	}
    	}
    	});
    	}

   //ACA CERRAMOS PUBLIC PANTALLA
    
private void initializePanelVectores() {
   JLabel LblNum2 = new JLabel("Operaciones con vectores");
   LblNum2.setHorizontalAlignment(SwingConstants.CENTER);
   LblNum2.setFont(new Font("Tahoma", Font.BOLD, 18));
   LblNum2.setBounds(10, 50, 439, 22);
   PanelVectores.add(LblNum2);
	}





private void initializePanelMatrices() {
		JLabel lblTitulo = new JLabel("Operaciones con matrices");
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblTitulo.setBounds(10, 70, 439, 22);
		PanelMatriz.add(lblTitulo);

		JLabel lblSubtitulo = new JLabel("Elegir tipo de matriz cuadrada:");
		lblSubtitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblSubtitulo.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblSubtitulo.setBounds(10, 108, 434, 22);
		PanelMatriz.add(lblSubtitulo);
		
		JButton btnNewButton = new JButton("2x2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Matriz2 Opcion1 = new Matriz2();
				Opcion1.setVisible(true);
			
			}
		});
		btnNewButton.setBackground(new Color(255, 113, 113));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(72, 152, 81, 37);
		PanelMatriz.add(btnNewButton);
		
		JButton btnx = new JButton("3x3");
		btnx.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Matriz3 Opcion2 = new Matriz3();
				Opcion2.setVisible(true);
			}
		});
		btnx.setForeground(new Color(255, 255, 255));
		btnx.setBackground(new Color(255, 113, 113));
		btnx.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnx.setBounds(194, 152, 81, 37);
		PanelMatriz.add(btnx);
		
		JButton btnx_1 = new JButton("4x4");
		btnx_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Matriz4 Opcion3 = new Matriz4();
				Opcion3.setVisible(true);
			}
		});
		btnx_1.setForeground(new Color(255, 255, 255));
		btnx_1.setBackground(new Color(255, 113, 113));
		btnx_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnx_1.setBounds(313, 152, 81, 37);
		PanelMatriz.add(btnx_1);
		
		table = new JTable();
		table.setBounds(187, 188, 1, 1);
		PanelMatriz.add(table);
		
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(215, 255, 215));
		frame.setBounds(100, 100, 450, 415);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		PanelMatriz.setLayout(null);	
	}

private void initializePanelSistEcu() {
        JLabel LblNum1 = new JLabel("Sistema de Ecuaciones");
        LblNum1.setHorizontalAlignment(SwingConstants.CENTER);
        LblNum1.setFont(new Font("Tahoma", Font.BOLD, 18));
        LblNum1.setBounds(10, 50, 439, 22);
PanelSisEcu.add(LblNum1);
	}
}
